let postButton = document.getElementById("postButton");
let clearButton = document.getElementById("clearButton");
let markButton = document.getElementById("markButton");
let deleteButton = document.getElementById("deleteButton");

postButton.addEventListener("click", (event) => {
    event.preventDefault();
    let todoTA = document.getElementById("newTodoTA");
    let todoText = todoTA.value;

    let div = document.createElement("div");
    div.className = "todo";

    // Create and append checkbox
    let input = document.createElement("input");
    input.className = "check";
    input.type = "checkbox";
    div.appendChild(input);

    // Create and append text
    let span = document.createElement("span");
    let spanText = document.createTextNode(" " + todoText);
    span.appendChild(spanText);
    div.appendChild(span);

    todoTA.value = "";
    document.getElementById("todo-list").append(div);
});

function checkAllTodos(param){
    let allTodos = document.getElementsByClassName("check");
    for (let check of allTodos)
        check.checked = param;
}

clearButton.addEventListener("click", (event) => {
    event.preventDefault();
    checkAllTodos(false);
});

markButton.addEventListener("click", (event) => {
    event.preventDefault();
    checkAllTodos(true);
});

deleteButton.addEventListener("click", (event) => {
    event.preventDefault();
    let to_Dos = document.getElementsByClassName("todo");

    while(to_Dos.length > 0)
        to_Dos[0].remove();
})